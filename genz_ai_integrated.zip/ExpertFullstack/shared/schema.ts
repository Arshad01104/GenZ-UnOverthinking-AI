import { z } from "zod";

export const categorySchema = z.enum([
  "social_anxiety",
  "relationship_stress",
  "family_friends",
  "study_pressure",
  "random_overthinking"
]);

export type Category = z.infer<typeof categorySchema>;

export const aiRequestSchema = z.object({
  userInput: z.string().min(1),
  category: categorySchema.optional(),
});

export type AIRequest = z.infer<typeof aiRequestSchema>;

export const aiResponseSchema = z.object({
  calmBreakdown: z.string(),
  realityCheck: z.array(z.string()),
  logicalExplanations: z.array(z.string()),
  actionStep: z.string(),
  confidenceBooster: z.string(),
});

export type AIResponse = z.infer<typeof aiResponseSchema>;

export const suggestedReplyRequestSchema = z.object({
  scenario: z.string().min(1),
  context: z.string().optional(),
});

export type SuggestedReplyRequest = z.infer<typeof suggestedReplyRequestSchema>;

export const suggestedReplyResponseSchema = z.object({
  bestReply: z.string(),
  alternatives: z.array(z.string()),
  whatNotToSay: z.string(),
});

export type SuggestedReplyResponse = z.infer<typeof suggestedReplyResponseSchema>;

export const chatSimulatorCategorySchema = z.enum([
  "crush_dm",
  "fight_with_friend",
  "ignored_messages",
  "confused_signals",
  "college_teacher",
  "stranger_intro"
]);

export type ChatSimulatorCategory = z.infer<typeof chatSimulatorCategorySchema>;

export const chatScenarioSchema = z.object({
  id: z.string(),
  category: chatSimulatorCategorySchema,
  title: z.string(),
  context: z.string(),
  messages: z.array(z.object({
    sender: z.enum(["other", "user"]),
    text: z.string(),
    isChoice: z.boolean().optional(),
  })),
  choices: z.array(z.object({
    id: z.string(),
    text: z.string(),
    score: z.number(),
    feedback: z.string(),
  })),
});

export type ChatScenario = z.infer<typeof chatScenarioSchema>;

export const historyEntrySchema = z.object({
  id: z.string(),
  timestamp: z.number(),
  userInput: z.string(),
  category: categorySchema.optional(),
  response: aiResponseSchema,
});

export type HistoryEntry = z.infer<typeof historyEntrySchema>;

export const safetyKeywords = [
  "suicide", "kill myself", "end my life", "want to die", 
  "self harm", "hurt myself", "cutting", "overdose",
  "no point living", "better off dead", "can't go on"
];

export function detectDistress(text: string): boolean {
  const lowerText = text.toLowerCase();
  return safetyKeywords.some(keyword => lowerText.includes(keyword));
}
