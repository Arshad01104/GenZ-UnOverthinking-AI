import type { Express } from "express";
import { createServer, type Server } from "http";
import { aiRequestSchema, suggestedReplyRequestSchema, type AIResponse, type SuggestedReplyResponse } from "@shared/schema";

const RAPIDAPI_KEY = "325f6025b2mshb4115012bfc4160p11f64ajsne65ffe1291e8";
const DEEPSEEK_API_URL = "https://deepseek-r1.p.rapidapi.com/v1/chat/completions";

async function callDeepSeekAPI(messages: { role: string; content: string }[]): Promise<string> {
  if (!RAPIDAPI_KEY) {
    throw new Error("RAPIDAPI_KEY is not configured");
  }

  try {
    const response = await fetch(DEEPSEEK_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": "deepseek-r1.p.rapidapi.com"
      },
      body: JSON.stringify({
        model: "deepseek-r1",
        messages,
        max_tokens: 2000,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      console.error("DeepSeek API error:", response.status, await response.text());
      throw new Error(`API request failed with status ${response.status}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "";
  } catch (error) {
    console.error("Error calling DeepSeek API:", error);
    throw error;
  }
}

function parseAIResponse(rawResponse: string): AIResponse {
  const calmBreakdownMatch = rawResponse.match(/calm breakdown[:\s]*([\s\S]*?)(?=reality check|$)/i);
  const realityCheckMatch = rawResponse.match(/reality check[:\s]*([\s\S]*?)(?=logical explanation|$)/i);
  const logicalMatch = rawResponse.match(/logical explanation[s]?[:\s]*([\s\S]*?)(?=action step|$)/i);
  const actionMatch = rawResponse.match(/action step[:\s]*([\s\S]*?)(?=confidence booster|$)/i);
  const confidenceMatch = rawResponse.match(/confidence booster[:\s]*([\s\S]*?)$/i);

  const extractPoints = (text: string | undefined): string[] => {
    if (!text) return [];
    const lines = text.split(/[\n•\-\d\.]+/).filter(line => line.trim().length > 10);
    return lines.slice(0, 3).map(l => l.trim());
  };

  return {
    calmBreakdown: calmBreakdownMatch?.[1]?.trim() || rawResponse.slice(0, 200),
    realityCheck: extractPoints(realityCheckMatch?.[1]) || [
      "This situation is temporary and manageable",
      "You've handled similar challenges before",
      "Your feelings are valid but don't define the outcome"
    ],
    logicalExplanations: extractPoints(logicalMatch?.[1]) || [
      "Most worst-case scenarios we imagine rarely happen",
      "Other people are usually more focused on themselves than judging you",
      "Taking action, even small steps, reduces anxiety more than avoidance"
    ],
    actionStep: actionMatch?.[1]?.trim() || "Take one small step right now - write down what you're feeling, take 3 deep breaths, or reach out to one person you trust.",
    confidenceBooster: confidenceMatch?.[1]?.trim() || "You are more capable than you give yourself credit for. The fact that you're seeking help shows strength, not weakness."
  };
}

function parseSuggestedReplyResponse(rawResponse: string): SuggestedReplyResponse {
  const bestMatch = rawResponse.match(/best reply[:\s]*([\s\S]*?)(?=alternative|$)/i);
  const altMatch = rawResponse.match(/alternative[s]?[:\s]*([\s\S]*?)(?=what not to say|don't say|$)/i);
  const notMatch = rawResponse.match(/(?:what not to say|don't say)[:\s]*([\s\S]*?)$/i);

  const extractAlternatives = (text: string | undefined): string[] => {
    if (!text) return [];
    const lines = text.split(/[\n•\-\d\.]+/).filter(line => line.trim().length > 10);
    return lines.slice(0, 3).map(l => l.trim());
  };

  return {
    bestReply: bestMatch?.[1]?.trim() || "I hear you, and I want to understand. Can we talk about this?",
    alternatives: extractAlternatives(altMatch?.[1]) || [
      "I've been thinking about this, and I'd like to work through it together.",
      "I appreciate you sharing this with me. Let's figure it out.",
      "Thanks for being honest. I'm open to hearing more."
    ],
    whatNotToSay: notMatch?.[1]?.trim() || "Avoid being defensive, dismissive, or making it about yourself. Don't say things like 'you're overreacting' or 'it's not a big deal.'"
  };
}

function generateFallbackAIResponse(userInput: string): AIResponse {
  const input = userInput.toLowerCase();
  
  let calmBreakdown = "I hear you - what you're feeling is completely valid. Let's break this down together and find some clarity.";
  
  if (input.includes("anxiety") || input.includes("anxious") || input.includes("nervous")) {
    calmBreakdown = "Anxiety can feel overwhelming, but it's your body trying to protect you. The feelings are temporary, even when they don't seem like it. Let's work through this together.";
  } else if (input.includes("relationship") || input.includes("partner") || input.includes("boyfriend") || input.includes("girlfriend")) {
    calmBreakdown = "Relationship stress is tough because we care deeply. Remember that healthy relationships involve open communication and both people growing together.";
  } else if (input.includes("friend") || input.includes("friendship")) {
    calmBreakdown = "Friendships go through phases, and tension doesn't mean the end. Good friends can work through challenges when both people are willing to communicate.";
  } else if (input.includes("school") || input.includes("study") || input.includes("exam") || input.includes("test")) {
    calmBreakdown = "Academic pressure can feel crushing, but remember: you've made it this far. One exam or assignment doesn't define your worth or your future.";
  }

  return {
    calmBreakdown,
    realityCheck: [
      "This situation, however difficult, is temporary",
      "You've successfully navigated challenges before",
      "Your worth isn't determined by this single moment or outcome"
    ],
    logicalExplanations: [
      "Our minds often catastrophize - imagining worst-case scenarios that rarely happen",
      "Most people are too focused on their own lives to judge you as harshly as you judge yourself",
      "Taking any action, even small, helps reduce the anxiety of uncertainty"
    ],
    actionStep: "Right now, take 3 slow, deep breaths. Then write down one tiny step you could take in the next 5 minutes - even if it's just texting a friend or getting a glass of water.",
    confidenceBooster: "You reached out for help, and that takes courage. You're already doing better than you think. Trust yourself - you've got this."
  };
}

function generateFallbackReplyResponse(scenario: string): SuggestedReplyResponse {
  return {
    bestReply: "Hey, I've been thinking about what you said and I want to understand where you're coming from. Can we talk about it when you have a moment?",
    alternatives: [
      "I appreciate you being honest with me. I'd love to work through this together if you're open to it.",
      "I hear you. I might not have all the answers right now, but I care about us figuring this out.",
      "Thanks for sharing that with me. I want to respond thoughtfully - can I get back to you after I've had a chance to process?"
    ],
    whatNotToSay: "Avoid dismissing their feelings ('you're overreacting'), getting defensive ('well YOU did this'), making excuses, or ghosting. These responses usually escalate tension instead of resolving it."
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/ai/calm", async (req, res) => {
    try {
      const parsed = aiRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid request body" });
      }

      const { userInput, category } = parsed.data;
      
      const categoryContext = category 
        ? `The user is experiencing ${category.replace(/_/g, " ")} related stress.`
        : "";

      const systemPrompt = `You are a supportive, Gen Z-friendly mental wellness AI assistant. Your goal is to help young people with overthinking, anxiety, and stress in a relatable, non-judgmental way.

${categoryContext}

Respond with the following sections clearly labeled:

CALM BREAKDOWN:
[Provide a compassionate, understanding summary of their situation in 2-3 sentences]

REALITY CHECK:
• [First reality check point]
• [Second reality check point]  
• [Third reality check point]

LOGICAL EXPLANATIONS:
1. [First logical explanation]
2. [Second logical explanation]
3. [Third logical explanation]

ACTION STEP:
[One specific, actionable step they can take right now]

CONFIDENCE BOOSTER:
[An encouraging, empowering message to boost their confidence]

Be warm, validating, and use casual Gen Z-appropriate language without being cringey. Focus on practical advice and emotional support.`;

      try {
        const rawResponse = await callDeepSeekAPI([
          { role: "system", content: systemPrompt },
          { role: "user", content: userInput }
        ]);
        
        const response = parseAIResponse(rawResponse);
        res.json(response);
      } catch (apiError) {
        console.log("Using fallback response due to API error");
        const fallbackResponse = generateFallbackAIResponse(userInput);
        res.json(fallbackResponse);
      }
    } catch (error) {
      console.error("Error in /api/ai/calm:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  app.post("/api/ai/reply", async (req, res) => {
    try {
      const parsed = suggestedReplyRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid request body" });
      }

      const { scenario, context } = parsed.data;
      
      const systemPrompt = `You are a social communication expert helping Gen Z craft the perfect responses to tricky situations. Be practical, empathetic, and aware of modern texting etiquette.

${context ? `Additional context: ${context}` : ""}

Respond with the following sections clearly labeled:

BEST REPLY:
[The ideal response they should send - natural, appropriate, and effective]

ALTERNATIVES:
1. [First alternative response]
2. [Second alternative response]
3. [Third alternative response]

WHAT NOT TO SAY:
[Explain what they should avoid saying and why]

Keep responses casual and age-appropriate. Consider tone, timing, and the relationship dynamics implied in the scenario.`;

      try {
        const rawResponse = await callDeepSeekAPI([
          { role: "system", content: systemPrompt },
          { role: "user", content: `Help me respond to this situation: ${scenario}` }
        ]);
        
        const response = parseSuggestedReplyResponse(rawResponse);
        res.json(response);
      } catch (apiError) {
        console.log("Using fallback response due to API error");
        const fallbackResponse = generateFallbackReplyResponse(scenario);
        res.json(fallbackResponse);
      }
    } catch (error) {
      console.error("Error in /api/ai/reply:", error);
      res.status(500).json({ error: "Failed to generate reply suggestions" });
    }
  });

  return httpServer;
}
