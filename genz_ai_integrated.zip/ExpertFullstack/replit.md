# GenZ UnOverthinking AI

## Overview

GenZ UnOverthinking AI is a mental wellness web application designed specifically for Gen Z users struggling with overthinking, social anxiety, relationship stress, and general mental overwhelm. The app provides AI-powered conversational support, suggested replies for difficult social situations, chat practice simulations, and mental reset tools. The application features a modern Gen Z aesthetic with neon gradients, dark themes, and playful micro-interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tools**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot module replacement
- Wouter for lightweight client-side routing (alternative to React Router)
- Framer Motion for animations and micro-interactions

**UI Component System**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library with "new-york" style variant
- Tailwind CSS for utility-first styling with custom design tokens
- Custom color system matching Gen Z aesthetic (deep navy background #1A1A2E, neon purple #8A00D4, vibrant pink #FF5CA2)
- Custom fonts: Poppins/Inter for body text, Lexend/Raleway for headers

**State Management**
- TanStack Query (React Query) for server state management and API caching
- Local component state with React hooks
- Client-side localStorage for chat history persistence (max 10 entries)

**Key Pages & Features**
- Home: Main entry point with category selection and input
- Chat: AI-powered conversation interface with safety overlay for distress detection
- SuggestedReply: Generates contextual reply suggestions for social situations
- ChatSimulator: Interactive practice scenarios with scoring and feedback
- ResetTools: Mental wellness tools (breathing exercises, grounding techniques, affirmations)
- History: Saved chat history with expandable entries

### Backend Architecture

**Server Framework**
- Express.js HTTP server with TypeScript
- Custom middleware for JSON parsing and request logging
- Static file serving for production builds

**API Design**
- RESTful endpoints under `/api` namespace
- POST `/api/ai/calm` - Main AI conversation endpoint
- POST `/api/ai/reply` - Suggested reply generation
- Request/response validation using Zod schemas

**External AI Integration**
- DeepSeek R1 API via RapidAPI for AI responses
- Custom prompt engineering to structure responses into categories:
  - Calm Breakdown
  - Reality Check (array of points)
  - Logical Explanations (array of points)
  - Action Step
  - Confidence Booster

**Data Validation**
- Shared schema definitions using Zod for type-safe validation
- Schema categories: social_anxiety, relationship_stress, family_friends, study_pressure, random_overthinking
- Built-in distress detection for triggering safety resources

**Safety Features**
- Client-side distress detection scanning for self-harm/crisis keywords
- Safety overlay component with crisis hotline resources (988 Lifeline, Crisis Text Line, IASP)

### Data Storage Solutions

**Current Implementation**
- Client-side localStorage for history persistence
- No server-side database currently implemented
- MemStorage stub class exists but is not actively used

**Database Configuration (Ready for Implementation)**
- Drizzle ORM configured for PostgreSQL
- Database migrations directory configured at `./migrations`
- Schema location at `./shared/schema.ts`
- Connection via `DATABASE_URL` environment variable

### Build & Deployment

**Development Mode**
- Vite dev server with HMR
- Express backend with tsx for TypeScript execution
- Replit-specific plugins: cartographer, dev-banner, runtime-error-modal

**Production Build**
- Client: Vite build outputs to `dist/public`
- Server: esbuild bundles server code to `dist/index.cjs`
- Bundling strategy: External dependencies except allowlisted packages (express, drizzle-orm, etc.) to reduce syscalls
- Static file serving from built client assets

## External Dependencies

### AI Service
- **DeepSeek R1 API** (via RapidAPI)
  - Endpoint: `https://deepseek-r1.p.rapidapi.com/v1/chat/completions`
  - Authentication: X-RapidAPI-Key header
  - Configuration: Environment variable `RAPIDAPI_KEY` required

### UI Libraries
- **Radix UI**: Accessible component primitives (accordion, dialog, dropdown, toast, etc.)
- **shadcn/ui**: Pre-built component library with Tailwind styling
- **Framer Motion**: Animation library for smooth transitions
- **Lucide React**: Icon library

### Utilities
- **TanStack Query**: Server state management and API caching
- **Zod**: Runtime schema validation and TypeScript type inference
- **class-variance-authority**: CSS class variant management
- **tailwind-merge**: Intelligent Tailwind class merging

### Development Tools
- **Replit Platform Integrations**: Cartographer (code mapping), dev banner, runtime error overlay
- **TypeScript**: Type safety across the stack
- **ESBuild**: Fast production bundling for server code
- **PostCSS & Autoprefixer**: CSS processing

### Potential Future Dependencies
- PostgreSQL database (configuration exists but not provisioned)
- Drizzle ORM for database operations
- connect-pg-simple for session management (if user authentication is added)