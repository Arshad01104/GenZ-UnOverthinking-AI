# Design Guidelines: GenZ UnOverthinking AI

## Design Approach
**Reference-Based Gen Z Aesthetic** - Drawing inspiration from modern Gen Z platforms like Discord, Duolingo, and Replika, with emphasis on neon gradients, dark themes, playful micro-interactions, and approachable mental wellness design.

---

## Color System

### Core Colors
- **Background**: `#1A1A2E` (deep navy black)
- **Primary Accent**: `#8A00D4` (neon purple)
- **Secondary Accent**: `#FF5CA2` (vibrant pink)
- **Text Primary**: `#FFFFFF` (white)
- **Text Secondary**: `#D3D3D3` (light grey)

### Gradients
- **Primary Gradient**: `#8A00D4 → #FF5CA2` (used for buttons, AI bubbles, emphasis elements)
- **Glow Effects**: Soft neon glows using purple/pink with blur and low opacity on hover states

---

## Typography

### Font Families
- **Primary**: Poppins or Inter (modern sans-serif for body text, buttons, labels)
- **Headers**: Lexend or Raleway (clean, rounded headers)

### Hierarchy
- **H1 (Main Title)**: 32-40px, medium weight, with subtle glowing underline effect
- **H2 (Section Headers)**: 24-28px, medium weight
- **H3 (Card Titles)**: 18-20px, medium weight
- **Body Text**: 14-16px, regular weight
- **Button Text**: 14-16px, medium weight, uppercase or sentence case
- **Labels**: 12-14px, regular weight

---

## Layout System

### Spacing Primitives
Use Tailwind units: **2, 4, 6, 8, 12, 16, 20** for consistent spacing throughout
- Small gaps: `p-2`, `m-4`
- Medium spacing: `p-6`, `m-8`
- Large sections: `p-12`, `py-16`, `py-20`

### Responsive Containers
- Mobile-first design (320px minimum)
- Max-width containers: `max-w-4xl` for content sections
- Full-width for immersive screens with inner padding

---

## Core Components

### A. Home Screen Layout
- **Header**: App title with glowing underline, centered or left-aligned
- **Main Input**: Floating label "What's bothering you?" with focus animations
- **Primary CTA**: Large "Calm Me" button with gradient background
- **Category Grid**: 5 quick-action buttons in 2-column mobile, 3-column tablet, 5-column desktop grid
  - Social Anxiety Helper
  - Relationship Stress
  - Family / Friends Issues
  - Study / Pressure
  - Random Overthinking Fix
- **Layout**: Vertical stack with generous spacing, slide-up/fade-in entrance animations

### B. AI Response Screen (Chat Interface)
- **Chat Bubbles**:
  - User: Semi-transparent purple `#5D3FD3` with rounded corners (24px), right-aligned
  - AI: Gradient `#8A00D4 → #FF5CA2` with soft shadow, left-aligned
- **Typing Indicator**: 3 bouncing dots animation
- **Content Structure**: Display calm breakdown, reality check points, logical explanations, confidence booster in structured format
- **Action Buttons**: "Get Suggested Reply", "Practice Chat", "Try 60-second Reset" below AI response
- **Auto-scroll**: Smooth scroll to newest message

### C. Suggested Reply Generator
- **Input/Context Display**: Show user's scenario in card
- **AI Output Cards**: 
  - Best Reply (prominent, larger card)
  - 3 Alternatives (smaller cards in grid)
  - What NOT to Say (warning-styled card with red accent)
- **Card Interactions**: Hover enlarge effect, copy and share buttons per card

### D. Social Anxiety Chat Simulator
- **Category Selection**: 6 buttons for scenario types (Crush DM, Fight with Friend, Ignored messages, Confused signals, College/Teacher, Stranger intro)
- **Chat Interface**: Similar to AI Response but with multiple-choice reply buttons
- **Progress Bar**: Confidence Score with gradient fill, animated on increase
- **Feedback**: Confetti/emoji pop animations on correct choices

### E. 60-Second Reset Tools
- **Circular Timer**: Large circle with pulsating gradient border animation
- **Exercise Cards**: Breathing exercises, grounding techniques, affirmations in scrollable cards
- **Timer States**: Start/pause/reset controls with icon buttons

### F. History/Past Entries
- **Card List**: Scrollable vertical list of last 10 entries
- **Card Design**: Rounded, semi-transparent background, preview of question + truncated response
- **Expand Interaction**: Tap to show full AI response with share/copy buttons
- **Empty State**: Friendly illustration when no history exists

### G. Safety Layer (Overlay)
- **Trigger**: Detect distress keywords
- **Overlay**: Semi-transparent dark backdrop with centered modal
- **Content**: Supportive message with soft red accent border, professional help links
- **Dismiss**: Close button with clear action

---

## Animations & Micro-Interactions

### Button States
- **Default**: Gradient background, rounded corners (12-16px)
- **Hover**: Glow effect (box-shadow with gradient colors), slight scale (1.02)
- **Active**: Ripple effect from tap point, vibration feedback on mobile
- **Loading**: Pulsing gradient animation

### Page Transitions
- **Entry**: Fade-in + slide-up (300ms ease-out)
- **Exit**: Fade-out (200ms)
- **Screen Changes**: Smooth cross-fade

### Chat Elements
- **Typing Indicator**: 3 dots with staggered bounce animation (infinite loop)
- **Message Appearance**: Slide-in from appropriate side + fade (200ms)
- **Cards**: Hover enlarge (scale 1.03) + shadow pop (increased blur/spread)

### Background (Optional Enhancement)
- Subtle gradient flow or soft star particles for depth (low opacity, non-distracting)

---

## Component Styling Patterns

### Cards
- **Background**: `rgba(138, 0, 212, 0.1)` or dark semi-transparent
- **Border Radius**: 16-20px
- **Shadow**: `0 4px 20px rgba(138, 0, 212, 0.2)`
- **Padding**: `p-6` to `p-8`

### Input Fields
- **Background**: Semi-transparent dark with subtle border
- **Border**: 1px solid `rgba(255, 255, 255, 0.1)`
- **Focus State**: Gradient border glow
- **Border Radius**: 12px
- **Padding**: `p-4`

### Buttons
- **Primary**: Gradient background, white text, no border
- **Secondary**: Transparent with gradient border, gradient text
- **Sizes**: Small (py-2 px-4), Medium (py-3 px-6), Large (py-4 px-8)
- **Border Radius**: 12px

---

## Images
**No hero images required** - This app uses gradient backgrounds and UI-focused design. Icons and emojis used throughout for visual interest:
- Emoji support in AI responses (subtle, contextual)
- Icons for category buttons (simple line icons in white/gradient)
- Optional background particle effects or abstract gradients

---

## Accessibility
- High contrast white text on dark backgrounds
- Focus states with visible outlines (gradient glow)
- Tap targets minimum 44x44px
- Smooth animations that respect `prefers-reduced-motion`
- ARIA labels for icon-only buttons

---

## Mobile Considerations
- **Touch-Optimized**: Large tap targets, swipe gestures where appropriate
- **Vibration Feedback**: On button taps and successful interactions
- **Responsive Grid**: Single column mobile, 2-3 columns tablet, up to 5 columns desktop
- **Bottom Navigation**: Consider sticky action buttons for primary CTAs