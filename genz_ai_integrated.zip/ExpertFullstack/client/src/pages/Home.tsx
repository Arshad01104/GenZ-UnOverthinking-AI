import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Brain, Users, Heart, BookOpen, Shuffle, Send, Sparkles } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { GradientButton } from "@/components/GradientButton";
import { CategoryCard } from "@/components/CategoryCard";
import { SafetyOverlay } from "@/components/SafetyOverlay";
import { detectDistress, type Category } from "@shared/schema";

const categories: { id: Category; label: string; icon: typeof Brain }[] = [
  { id: "social_anxiety", label: "Social Anxiety Helper", icon: Users },
  { id: "relationship_stress", label: "Relationship Stress", icon: Heart },
  { id: "family_friends", label: "Family / Friends Issues", icon: Users },
  { id: "study_pressure", label: "Study / Pressure", icon: BookOpen },
  { id: "random_overthinking", label: "Random Overthinking Fix", icon: Shuffle }
];

export default function Home() {
  const [, navigate] = useLocation();
  const [input, setInput] = useState("");
  const [showSafety, setShowSafety] = useState(false);

  const handleSubmit = (category?: Category) => {
    if (!input.trim()) return;
    
    if (detectDistress(input)) {
      setShowSafety(true);
      return;
    }

    const params = new URLSearchParams();
    params.set("q", input);
    if (category) params.set("cat", category);
    navigate(`/chat?${params.toString()}`);
  };

  const handleCategoryClick = (category: Category) => {
    if (input.trim()) {
      handleSubmit(category);
    } else {
      const prompts: Record<Category, string> = {
        social_anxiety: "I'm feeling really anxious about a social situation...",
        relationship_stress: "I'm stressed about my relationship...",
        family_friends: "I'm having issues with family/friends...",
        study_pressure: "I'm overwhelmed with studies/work...",
        random_overthinking: "I can't stop overthinking about..."
      };
      setInput(prompts[category]);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <SafetyOverlay isOpen={showSafety} onClose={() => setShowSafety(false)} />
      
      <div className="max-w-lg mx-auto px-4 pt-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-[#FF5CA2]" />
            <h1 className="text-2xl md:text-3xl font-bold font-display bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] bg-clip-text text-transparent">
              GenZ UnOverthinking AI
            </h1>
          </div>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] rounded-full mb-4 animate-pulse-glow" />
          <p className="text-muted-foreground text-sm">
            Stop overthinking. Start living. We've got your back.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="relative mb-6"
        >
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] rounded-xl blur opacity-30 group-focus-within:opacity-60 transition-opacity" />
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="What's bothering you?"
              className="relative min-h-[120px] bg-card border-border/50 resize-none text-base placeholder:text-muted-foreground/60 focus:border-[#8A00D4]/50"
              data-testid="input-main"
            />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-8"
        >
          <GradientButton 
            onClick={() => handleSubmit()}
            disabled={!input.trim()}
            className="w-full"
            size="lg"
            data-testid="button-calm-me"
          >
            <span className="flex items-center justify-center gap-2">
              <Brain className="w-5 h-5" />
              Calm Me
            </span>
          </GradientButton>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mb-4"
        >
          <p className="text-sm text-muted-foreground text-center mb-4">
            Or pick what's on your mind:
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-3 mb-8">
          {categories.map((cat, index) => (
            <CategoryCard
              key={cat.id}
              icon={cat.icon}
              label={cat.label}
              onClick={() => handleCategoryClick(cat.id)}
              delay={0.3 + index * 0.1}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="text-center"
        >
          <button
            onClick={() => navigate("/simulator")}
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-practice-chat"
          >
            <Send className="w-4 h-4" />
            Want to practice responding? Try the Chat Simulator
          </button>
        </motion.div>
      </div>
    </div>
  );
}
