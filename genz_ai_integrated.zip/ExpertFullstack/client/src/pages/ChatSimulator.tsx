import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Heart, Users, MessageCircleOff, HelpCircle, GraduationCap, UserPlus, Trophy, RefreshCw, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ChatBubble } from "@/components/ChatBubble";
import { GradientButton } from "@/components/GradientButton";
import { chatScenarios, categoryLabels, getScenariosByCategory } from "@/lib/scenarios";
import type { ChatScenario, ChatSimulatorCategory } from "@shared/schema";

const iconMap = {
  Heart,
  Users,
  MessageCircleOff,
  HelpCircle,
  GraduationCap,
  UserPlus
};

export default function ChatSimulator() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<ChatSimulatorCategory | null>(null);
  const [currentScenario, setCurrentScenario] = useState<ChatScenario | null>(null);
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleCategorySelect = (category: ChatSimulatorCategory) => {
    setSelectedCategory(category);
    const scenarios = getScenariosByCategory(category);
    if (scenarios.length > 0) {
      setCurrentScenario(scenarios[0]);
    }
    setScore(0);
    setTotalQuestions(0);
    setSelectedChoice(null);
  };

  const handleChoiceSelect = (choiceId: string) => {
    if (selectedChoice) return;
    
    setSelectedChoice(choiceId);
    setTotalQuestions(prev => prev + 1);
    
    const choice = currentScenario?.choices.find(c => c.id === choiceId);
    if (choice && choice.score >= 2) {
      setScore(prev => prev + choice.score);
      if (choice.score === 3) {
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 1500);
      }
    }
  };

  const handleNext = () => {
    if (!selectedCategory) return;
    
    const scenarios = getScenariosByCategory(selectedCategory);
    const currentIndex = scenarios.findIndex(s => s.id === currentScenario?.id);
    
    if (currentIndex < scenarios.length - 1) {
      setCurrentScenario(scenarios[currentIndex + 1]);
      setSelectedChoice(null);
    } else {
      setCurrentScenario(null);
    }
  };

  const handleRestart = () => {
    setSelectedCategory(null);
    setCurrentScenario(null);
    setSelectedChoice(null);
    setScore(0);
    setTotalQuestions(0);
  };

  const maxScore = totalQuestions * 3;
  const scorePercentage = maxScore > 0 ? (score / maxScore) * 100 : 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-lg border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => selectedCategory ? handleRestart() : navigate("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold">Chat Simulator</span>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          {!selectedCategory ? (
            <motion.div
              key="categories"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="text-center mb-6">
                <h2 className="text-xl font-semibold mb-2">Practice Your Responses</h2>
                <p className="text-muted-foreground text-sm">
                  Choose a scenario type to practice handling tricky conversations
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {(Object.entries(categoryLabels) as [ChatSimulatorCategory, { label: string; icon: string }][]).map(
                  ([category, { label, icon }], index) => {
                    const IconComponent = iconMap[icon as keyof typeof iconMap];
                    const scenarioCount = getScenariosByCategory(category).length;
                    
                    return (
                      <motion.button
                        key={category}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() => handleCategorySelect(category)}
                        className="p-4 rounded-xl bg-card/50 border border-border/50 hover:border-[#8A00D4]/50 transition-all text-left group"
                        data-testid={`category-${category}`}
                      >
                        <div className="p-3 rounded-full bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20 w-fit mb-3 group-hover:from-[#8A00D4]/30 group-hover:to-[#FF5CA2]/30">
                          <IconComponent className="w-5 h-5 text-[#FF5CA2]" />
                        </div>
                        <h3 className="font-medium text-foreground mb-1">{label}</h3>
                        <p className="text-xs text-muted-foreground">{scenarioCount} scenarios</p>
                      </motion.button>
                    );
                  }
                )}
              </div>
            </motion.div>
          ) : currentScenario ? (
            <motion.div
              key="scenario"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Confidence Score</span>
                  <span className="text-sm font-medium text-[#FF5CA2]">{score} pts</span>
                </div>
                <Progress value={scorePercentage} className="h-2" />
              </div>

              <Card className="mb-4 bg-card/50">
                <CardContent className="pt-4">
                  <h3 className="font-semibold mb-2">{currentScenario.title}</h3>
                  <p className="text-sm text-muted-foreground">{currentScenario.context}</p>
                </CardContent>
              </Card>

              <div className="space-y-3 mb-4">
                {currentScenario.messages.map((msg, index) => (
                  <ChatBubble key={index} sender={msg.sender === "user" ? "user" : "ai"}>
                    <p className="text-sm">{msg.text}</p>
                  </ChatBubble>
                ))}
              </div>

              {!selectedChoice ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground mb-3">Choose your response:</p>
                  {currentScenario.choices.map((choice, index) => (
                    <motion.button
                      key={choice.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => handleChoiceSelect(choice.id)}
                      className="w-full p-4 text-left rounded-xl bg-card border border-border/50 hover:border-[#8A00D4]/50 transition-all"
                      data-testid={`choice-${choice.id}`}
                    >
                      <p className="text-sm">{choice.text}</p>
                    </motion.button>
                  ))}
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {currentScenario.choices.map((choice) => {
                    const isSelected = choice.id === selectedChoice;
                    const isGood = choice.score >= 2;
                    
                    return (
                      <div
                        key={choice.id}
                        className={`p-4 rounded-xl mb-2 border ${
                          isSelected
                            ? isGood
                              ? "bg-green-500/20 border-green-500/50"
                              : "bg-red-500/20 border-red-500/50"
                            : choice.score === 3
                            ? "bg-green-500/10 border-green-500/30"
                            : "bg-card/30 border-border/30"
                        }`}
                      >
                        <p className="text-sm mb-2">{choice.text}</p>
                        {(isSelected || choice.score === 3) && (
                          <p className="text-xs text-muted-foreground italic">{choice.feedback}</p>
                        )}
                      </div>
                    );
                  })}

                  <GradientButton onClick={handleNext} className="w-full mt-4" data-testid="button-next">
                    {getScenariosByCategory(selectedCategory).findIndex(s => s.id === currentScenario.id) <
                    getScenariosByCategory(selectedCategory).length - 1
                      ? "Next Scenario"
                      : "See Results"}
                  </GradientButton>
                </motion.div>
              )}

              {showConfetti && (
                <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
                  {[...Array(12)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ y: 0, x: 0, opacity: 1, scale: 1 }}
                      animate={{
                        y: -200 - Math.random() * 100,
                        x: (Math.random() - 0.5) * 300,
                        opacity: 0,
                        scale: 0.5,
                        rotate: Math.random() * 360
                      }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className="absolute text-3xl"
                    >
                      {["🎉", "⭐", "🔥", "💪", "✨"][Math.floor(Math.random() * 5)]}
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8"
            >
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] flex items-center justify-center">
                <Trophy className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-2xl font-bold mb-2">Great Practice!</h2>
              <p className="text-muted-foreground mb-6">
                You scored {score} out of {maxScore} possible points
              </p>

              <div className="bg-card/50 rounded-xl p-6 mb-6">
                <div className="text-4xl font-bold bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] bg-clip-text text-transparent">
                  {Math.round(scorePercentage)}%
                </div>
                <p className="text-sm text-muted-foreground mt-2">Confidence Score</p>
              </div>

              <div className="space-y-3">
                <GradientButton onClick={handleRestart} className="w-full" data-testid="button-try-again">
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Try Another Category
                </GradientButton>
                <GradientButton
                  variant="secondary"
                  onClick={() => {
                    setCurrentScenario(getScenariosByCategory(selectedCategory)[0]);
                    setSelectedChoice(null);
                    setScore(0);
                    setTotalQuestions(0);
                  }}
                  className="w-full"
                  data-testid="button-practice-again"
                >
                  Practice Same Category Again
                </GradientButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
