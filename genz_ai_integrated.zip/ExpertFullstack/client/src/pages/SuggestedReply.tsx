import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Send, Copy, Check, AlertTriangle, Sparkles } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GradientButton } from "@/components/GradientButton";
import { TypingIndicator } from "@/components/TypingIndicator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { SuggestedReplyResponse } from "@shared/schema";

export default function SuggestedReply() {
  const [, navigate] = useLocation();
  const [scenario, setScenario] = useState("");
  const [context, setContext] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const { toast } = useToast();

  const replyMutation = useMutation({
    mutationFn: async (data: { scenario: string; context?: string }) => {
      const response = await apiRequest("POST", "/api/ai/reply", data);
      return response as SuggestedReplyResponse;
    },
    onError: () => {
      toast({
        title: "Something went wrong",
        description: "Couldn't generate replies. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = () => {
    if (!scenario.trim()) return;
    replyMutation.mutate({ scenario, context: context || undefined });
  };

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      toast({ description: "Copied to clipboard!" });
    } catch {
      toast({ description: "Failed to copy", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-lg border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]">
              <Send className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold">Suggested Reply Generator</span>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 mb-6"
        >
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              What do you need to respond to?
            </label>
            <Textarea
              value={scenario}
              onChange={(e) => setScenario(e.target.value)}
              placeholder="e.g., My friend texted 'we need to talk' and I don't know what to say..."
              className="min-h-[100px] bg-card border-border/50"
              data-testid="input-scenario"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Any extra context? (optional)
            </label>
            <Textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="e.g., We had a small argument last week about..."
              className="min-h-[80px] bg-card border-border/50"
              data-testid="input-context"
            />
          </div>

          <GradientButton
            onClick={handleSubmit}
            disabled={!scenario.trim() || replyMutation.isPending}
            isLoading={replyMutation.isPending}
            className="w-full"
            data-testid="button-generate"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Generate Replies
          </GradientButton>
        </motion.div>

        {replyMutation.isPending && (
          <div className="flex justify-center py-8">
            <TypingIndicator />
          </div>
        )}

        {replyMutation.data && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card className="border-2 border-[#8A00D4]/30 bg-gradient-to-r from-[#8A00D4]/10 to-[#FF5CA2]/10">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#FF5CA2]" />
                  Best Reply
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground mb-3">{replyMutation.data.bestReply}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(replyMutation.data.bestReply, "best")}
                  data-testid="button-copy-best"
                >
                  {copiedId === "best" ? (
                    <Check className="w-4 h-4 mr-2 text-green-500" />
                  ) : (
                    <Copy className="w-4 h-4 mr-2" />
                  )}
                  {copiedId === "best" ? "Copied!" : "Copy"}
                </Button>
              </CardContent>
            </Card>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Alternatives</h3>
              <div className="space-y-3">
                {replyMutation.data.alternatives.map((alt, index) => (
                  <Card key={index} className="bg-card/50">
                    <CardContent className="py-4">
                      <p className="text-foreground text-sm mb-2">{alt}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(alt, `alt-${index}`)}
                        data-testid={`button-copy-alt-${index}`}
                      >
                        {copiedId === `alt-${index}` ? (
                          <Check className="w-4 h-4 mr-2 text-green-500" />
                        ) : (
                          <Copy className="w-4 h-4 mr-2" />
                        )}
                        {copiedId === `alt-${index}` ? "Copied!" : "Copy"}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <Card className="border-destructive/30 bg-destructive/10">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2 text-destructive">
                  <AlertTriangle className="w-5 h-5" />
                  What NOT to Say
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground text-sm">{replyMutation.data.whatNotToSay}</p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
