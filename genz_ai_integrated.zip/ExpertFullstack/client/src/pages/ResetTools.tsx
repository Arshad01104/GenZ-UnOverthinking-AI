import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Play, Pause, RotateCcw, Wind, Eye, Sun, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GradientButton } from "@/components/GradientButton";

const affirmations = [
  "You are capable of handling whatever comes your way.",
  "This moment will pass. You've survived 100% of your worst days.",
  "Your feelings are valid, but they don't define your reality.",
  "You are doing better than you think.",
  "It's okay to not have all the answers right now.",
  "You are worthy of love and belonging, exactly as you are.",
  "Progress, not perfection. Every small step counts.",
  "You have overcome challenges before, and you will again.",
  "This anxiety is temporary. Your strength is permanent.",
  "You are allowed to take up space and be heard."
];

const groundingSteps = [
  { sense: "See", prompt: "Name 5 things you can see right now", icon: Eye },
  { sense: "Touch", prompt: "Name 4 things you can physically feel", icon: "hand" },
  { sense: "Hear", prompt: "Name 3 things you can hear", icon: "ear" },
  { sense: "Smell", prompt: "Name 2 things you can smell", icon: "flower" },
  { sense: "Taste", prompt: "Name 1 thing you can taste", icon: "coffee" }
];

export default function ResetTools() {
  const [, navigate] = useLocation();
  const [timeLeft, setTimeLeft] = useState(60);
  const [isRunning, setIsRunning] = useState(false);
  const [breathPhase, setBreathPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [groundingStep, setGroundingStep] = useState(0);
  const [currentAffirmation, setCurrentAffirmation] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timeLeft]);

  useEffect(() => {
    if (isRunning) {
      const breathCycle = setInterval(() => {
        setBreathPhase(prev => {
          if (prev === "inhale") return "hold";
          if (prev === "hold") return "exhale";
          return "inhale";
        });
      }, 4000);
      return () => clearInterval(breathCycle);
    }
  }, [isRunning]);

  const toggleTimer = () => setIsRunning(!isRunning);
  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(60);
    setBreathPhase("inhale");
  };

  const nextAffirmation = () => {
    setCurrentAffirmation(prev => (prev + 1) % affirmations.length);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const progress = ((60 - timeLeft) / 60) * 100;

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-lg border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]">
              <Timer className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold">60-Second Reset</span>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="relative w-48 h-48 mx-auto mb-6">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                className="text-muted/30"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="url(#gradient)"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 88}`}
                strokeDashoffset={`${2 * Math.PI * 88 * (1 - progress / 100)}`}
                className="transition-all duration-1000"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8A00D4" />
                  <stop offset="100%" stopColor="#FF5CA2" />
                </linearGradient>
              </defs>
            </svg>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <motion.span
                key={timeLeft}
                initial={{ scale: 1.2, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-4xl font-bold font-display"
              >
                {formatTime(timeLeft)}
              </motion.span>
              
              {isRunning && (
                <motion.div
                  animate={{ scale: breathPhase === "inhale" ? 1.1 : breathPhase === "hold" ? 1.05 : 0.95 }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                  className="mt-2"
                >
                  <span className="text-sm text-muted-foreground capitalize">
                    {breathPhase === "inhale" ? "Breathe In..." : breathPhase === "hold" ? "Hold..." : "Breathe Out..."}
                  </span>
                </motion.div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={resetTimer}
              data-testid="button-reset-timer"
            >
              <RotateCcw className="w-5 h-5" />
            </Button>
            <GradientButton
              onClick={toggleTimer}
              size="lg"
              className="px-8"
              data-testid="button-toggle-timer"
            >
              {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </GradientButton>
          </div>
        </motion.div>

        <Tabs defaultValue="breathing" className="mt-8">
          <TabsList className="grid w-full grid-cols-3 bg-card">
            <TabsTrigger value="breathing" data-testid="tab-breathing">
              <Wind className="w-4 h-4 mr-2" />
              Breathing
            </TabsTrigger>
            <TabsTrigger value="grounding" data-testid="tab-grounding">
              <Eye className="w-4 h-4 mr-2" />
              Grounding
            </TabsTrigger>
            <TabsTrigger value="affirmations" data-testid="tab-affirmations">
              <Sun className="w-4 h-4 mr-2" />
              Affirm
            </TabsTrigger>
          </TabsList>

          <TabsContent value="breathing" className="mt-4">
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="text-lg">Box Breathing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  A simple technique to calm your nervous system:
                </p>
                <div className="space-y-3">
                  {["Inhale for 4 seconds", "Hold for 4 seconds", "Exhale for 4 seconds", "Hold for 4 seconds"].map((step, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20 flex items-center justify-center text-sm font-medium">
                        {i + 1}
                      </div>
                      <span className="text-sm">{step}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-4 italic">
                  Start the timer above to practice with guided breathing
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="grounding" className="mt-4">
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="text-lg">5-4-3-2-1 Grounding</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Use your senses to anchor yourself to the present:
                </p>
                <div className="space-y-4">
                  {groundingSteps.map((step, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0.5 }}
                      animate={{ opacity: groundingStep >= i ? 1 : 0.5 }}
                      className={`p-4 rounded-xl border transition-all cursor-pointer ${
                        groundingStep === i
                          ? "border-[#8A00D4]/50 bg-[#8A00D4]/10"
                          : groundingStep > i
                          ? "border-green-500/30 bg-green-500/10"
                          : "border-border/50 bg-card/30"
                      }`}
                      onClick={() => setGroundingStep(i)}
                      data-testid={`grounding-step-${i}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-lg font-bold ${
                          groundingStep > i ? "bg-green-500 text-white" : "bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20"
                        }`}>
                          {5 - i}
                        </div>
                        <div>
                          <p className="font-medium text-sm">{step.sense}</p>
                          <p className="text-xs text-muted-foreground">{step.prompt}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                {groundingStep < 4 && (
                  <Button
                    variant="ghost"
                    className="w-full mt-4"
                    onClick={() => setGroundingStep(prev => Math.min(prev + 1, 4))}
                    data-testid="button-next-grounding"
                  >
                    Next Step
                  </Button>
                )}
                {groundingStep === 4 && (
                  <GradientButton
                    className="w-full mt-4"
                    onClick={() => setGroundingStep(0)}
                    data-testid="button-restart-grounding"
                  >
                    Start Over
                  </GradientButton>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="affirmations" className="mt-4">
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="text-lg">Positive Affirmations</CardTitle>
              </CardHeader>
              <CardContent>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentAffirmation}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="min-h-[100px] flex items-center justify-center"
                  >
                    <p className="text-lg text-center leading-relaxed font-medium bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] bg-clip-text text-transparent">
                      "{affirmations[currentAffirmation]}"
                    </p>
                  </motion.div>
                </AnimatePresence>
                <GradientButton
                  variant="secondary"
                  className="w-full mt-4"
                  onClick={nextAffirmation}
                  data-testid="button-next-affirmation"
                >
                  Next Affirmation
                </GradientButton>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
