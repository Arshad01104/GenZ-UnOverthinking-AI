import { useState, useEffect, useRef } from "react";
import { useLocation, useSearch } from "wouter";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Send, MessageSquare, Sparkles, Timer, Copy, Check } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ChatBubble } from "@/components/ChatBubble";
import { TypingIndicator } from "@/components/TypingIndicator";
import { GradientButton } from "@/components/GradientButton";
import { SafetyOverlay } from "@/components/SafetyOverlay";
import { useToast } from "@/hooks/use-toast";
import { addToHistory } from "@/lib/history";
import { apiRequest } from "@/lib/queryClient";
import { detectDistress, type AIResponse, type Category } from "@shared/schema";

interface Message {
  id: string;
  sender: "user" | "ai";
  content: string | AIResponse;
}

function normalizeAIResponse(data: unknown): AIResponse {
  const defaultResponse: AIResponse = {
    calmBreakdown: "I hear you - let's work through this together.",
    realityCheck: [
      "This situation is temporary and manageable",
      "You've handled challenges before",
      "Your feelings are valid but don't define the outcome"
    ],
    logicalExplanations: [
      "Most worst-case scenarios we imagine rarely happen",
      "People are usually focused on themselves, not judging you",
      "Taking action reduces anxiety more than avoidance"
    ],
    actionStep: "Take a deep breath and write down one small step you can take right now.",
    confidenceBooster: "You're already showing strength by seeking help. You've got this."
  };

  if (!data || typeof data !== 'object') {
    return defaultResponse;
  }

  const response = data as Record<string, unknown>;
  
  return {
    calmBreakdown: typeof response.calmBreakdown === 'string' && response.calmBreakdown 
      ? response.calmBreakdown 
      : defaultResponse.calmBreakdown,
    realityCheck: Array.isArray(response.realityCheck) && response.realityCheck.length > 0
      ? response.realityCheck.filter((item): item is string => typeof item === 'string')
      : defaultResponse.realityCheck,
    logicalExplanations: Array.isArray(response.logicalExplanations) && response.logicalExplanations.length > 0
      ? response.logicalExplanations.filter((item): item is string => typeof item === 'string')
      : defaultResponse.logicalExplanations,
    actionStep: typeof response.actionStep === 'string' && response.actionStep
      ? response.actionStep
      : defaultResponse.actionStep,
    confidenceBooster: typeof response.confidenceBooster === 'string' && response.confidenceBooster
      ? response.confidenceBooster
      : defaultResponse.confidenceBooster
  };
}

export default function Chat() {
  const [, navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initialQuery = params.get("q") || "";
  const category = params.get("cat") as Category | null;
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [showSafety, setShowSafety] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const aiMutation = useMutation({
    mutationFn: async (data: { userInput: string; category?: Category }) => {
      const response = await apiRequest("POST", "/api/ai/calm", data);
      return normalizeAIResponse(response);
    },
    onSuccess: (data, variables) => {
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        sender: "ai",
        content: data
      };
      setMessages(prev => [...prev, aiMessage]);
      
      addToHistory({
        id: `history-${Date.now()}`,
        timestamp: Date.now(),
        userInput: variables.userInput,
        category: variables.category,
        response: data
      });
    },
    onError: () => {
      toast({
        title: "Something went wrong",
        description: "Couldn't get a response. Please try again.",
        variant: "destructive"
      });
    }
  });

  useEffect(() => {
    if (initialQuery && messages.length === 0) {
      const userMessage: Message = {
        id: `user-${Date.now()}`,
        sender: "user",
        content: initialQuery
      };
      setMessages([userMessage]);
      aiMutation.mutate({ userInput: initialQuery, category: category || undefined });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, aiMutation.isPending]);

  const handleSend = () => {
    if (!input.trim()) return;

    if (detectDistress(input)) {
      setShowSafety(true);
      return;
    }

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      content: input
    };
    setMessages(prev => [...prev, userMessage]);
    aiMutation.mutate({ userInput: input, category: category || undefined });
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      toast({ description: "Copied to clipboard!" });
    } catch {
      toast({ description: "Failed to copy", variant: "destructive" });
    }
  };

  const formatAIResponse = (response: AIResponse): string => {
    const realityCheck = response.realityCheck || [];
    const logicalExplanations = response.logicalExplanations || [];
    return `Calm Breakdown:\n${response.calmBreakdown || ''}\n\nReality Check:\n${realityCheck.map(r => `• ${r}`).join('\n')}\n\nLogical Explanations:\n${logicalExplanations.map((e, i) => `${i + 1}. ${e}`).join('\n')}\n\nAction Step:\n${response.actionStep || ''}\n\nConfidence Booster:\n${response.confidenceBooster || ''}`;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <SafetyOverlay isOpen={showSafety} onClose={() => setShowSafety(false)} />
      
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-lg border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold">UnOverthinking AI</span>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto pb-40">
        <div className="max-w-lg mx-auto px-4 py-4 space-y-4">
          {messages.map((message) => (
            <ChatBubble key={message.id} sender={message.sender}>
              {message.sender === "user" ? (
                <p className="text-sm md:text-base">{message.content as string}</p>
              ) : (
                <div className="space-y-4">
                  {(() => {
                    const response = normalizeAIResponse(message.content);
                    const realityCheck = response.realityCheck;
                    const logicalExplanations = response.logicalExplanations;
                    return (
                      <>
                        <div>
                          <h4 className="font-semibold text-sm mb-2 opacity-90">Calm Breakdown</h4>
                          <p className="text-sm leading-relaxed">{response.calmBreakdown || "Taking a moment to understand your situation..."}</p>
                        </div>
                        
                        {realityCheck.length > 0 && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2 opacity-90">Reality Check</h4>
                            <ul className="space-y-1">
                              {realityCheck.map((point, i) => (
                                <li key={i} className="text-sm flex gap-2">
                                  <span className="text-[#FF5CA2]">•</span>
                                  <span>{point}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {logicalExplanations.length > 0 && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2 opacity-90">Logical Explanations</h4>
                            <ol className="space-y-2">
                              {logicalExplanations.map((exp, i) => (
                                <li key={i} className="text-sm flex gap-2">
                                  <span className="font-semibold text-[#FF5CA2]">{i + 1}.</span>
                                  <span>{exp}</span>
                                </li>
                              ))}
                            </ol>
                          </div>
                        )}
                        
                        {response.actionStep && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2 opacity-90">Action Step</h4>
                            <p className="text-sm leading-relaxed">{response.actionStep}</p>
                          </div>
                        )}
                        
                        {response.confidenceBooster && (
                          <div className="pt-2 border-t border-white/20">
                            <h4 className="font-semibold text-sm mb-2 opacity-90">Confidence Booster</h4>
                            <p className="text-sm leading-relaxed italic">{response.confidenceBooster}</p>
                          </div>
                        )}

                        <Button
                          variant="ghost"
                          size="sm"
                          className="mt-2 text-white/70 hover:text-white hover:bg-white/10"
                          onClick={() => copyToClipboard(formatAIResponse(response), message.id)}
                          data-testid={`button-copy-${message.id}`}
                        >
                          {copiedId === message.id ? (
                            <Check className="w-4 h-4 mr-2" />
                          ) : (
                            <Copy className="w-4 h-4 mr-2" />
                          )}
                          {copiedId === message.id ? "Copied!" : "Copy"}
                        </Button>
                      </>
                    );
                  })()}
                </div>
              )}
            </ChatBubble>
          ))}
          
          {aiMutation.isPending && (
            <div className="flex justify-start">
              <TypingIndicator />
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {messages.some(m => m.sender === "ai") && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-24 left-0 right-0 px-4 z-20"
        >
          <div className="max-w-lg mx-auto flex gap-2 overflow-x-auto pb-2">
            <GradientButton
              variant="secondary"
              size="sm"
              onClick={() => navigate("/reply")}
              className="whitespace-nowrap"
              data-testid="button-suggested-reply"
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              Get Suggested Reply
            </GradientButton>
            <GradientButton
              variant="secondary"
              size="sm"
              onClick={() => navigate("/simulator")}
              className="whitespace-nowrap"
              data-testid="button-practice-chat"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Practice Chat
            </GradientButton>
            <GradientButton
              variant="secondary"
              size="sm"
              onClick={() => navigate("/reset")}
              className="whitespace-nowrap"
              data-testid="button-reset"
            >
              <Timer className="w-4 h-4 mr-2" />
              60-Second Reset
            </GradientButton>
          </div>
        </motion.div>
      )}

      <div className="fixed bottom-16 left-0 right-0 bg-card/95 backdrop-blur-lg border-t border-border px-4 py-3 z-30">
        <div className="max-w-lg mx-auto flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your thoughts..."
            className="min-h-[44px] max-h-[120px] resize-none bg-muted/50"
            data-testid="input-chat"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || aiMutation.isPending}
            className="bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] hover:opacity-90"
            size="icon"
            data-testid="button-send"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
