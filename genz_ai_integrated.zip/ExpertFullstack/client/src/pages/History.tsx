import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, History as HistoryIcon, ChevronDown, ChevronUp, Copy, Trash2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GradientButton } from "@/components/GradientButton";
import { useToast } from "@/hooks/use-toast";
import { getHistory, removeFromHistory, clearHistory } from "@/lib/history";
import type { HistoryEntry, Category } from "@shared/schema";

const categoryLabels: Record<Category, string> = {
  social_anxiety: "Social Anxiety",
  relationship_stress: "Relationship",
  family_friends: "Family/Friends",
  study_pressure: "Study/Pressure",
  random_overthinking: "Overthinking"
};

export default function HistoryPage() {
  const [, navigate] = useLocation();
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setEntries(getHistory());
  }, []);

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const handleDelete = (id: string) => {
    removeFromHistory(id);
    setEntries(entries.filter(e => e.id !== id));
    toast({ description: "Entry deleted" });
  };

  const handleClearAll = () => {
    clearHistory();
    setEntries([]);
    toast({ description: "History cleared" });
  };

  const copyToClipboard = async (entry: HistoryEntry) => {
    const text = `Question: ${entry.userInput}\n\nCalm Breakdown:\n${entry.response.calmBreakdown}\n\nReality Check:\n${entry.response.realityCheck.map(r => `• ${r}`).join('\n')}\n\nLogical Explanations:\n${entry.response.logicalExplanations.map((e, i) => `${i + 1}. ${e}`).join('\n')}\n\nAction Step:\n${entry.response.actionStep}\n\nConfidence Booster:\n${entry.response.confidenceBooster}`;
    
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(entry.id);
      setTimeout(() => setCopiedId(null), 2000);
      toast({ description: "Copied to clipboard!" });
    } catch {
      toast({ description: "Failed to copy", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-lg border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-full bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]">
                <HistoryIcon className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold">History</span>
            </div>
          </div>
          {entries.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearAll}
              className="text-muted-foreground hover:text-destructive"
              data-testid="button-clear-all"
            >
              Clear All
            </Button>
          )}
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6">
        {entries.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20 flex items-center justify-center">
              <HistoryIcon className="w-10 h-10 text-[#FF5CA2]" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No History Yet</h3>
            <p className="text-muted-foreground text-sm mb-6">
              Your past conversations will appear here
            </p>
            <GradientButton onClick={() => navigate("/")} data-testid="button-start-chat">
              Start a Conversation
            </GradientButton>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {entries.map((entry, index) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-card/50 overflow-hidden">
                  <CardContent className="p-0">
                    <button
                      onClick={() => setExpandedId(expandedId === entry.id ? null : entry.id)}
                      className="w-full p-4 text-left"
                      data-testid={`entry-${entry.id}`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <p className="text-sm font-medium line-clamp-2 flex-1">
                          {entry.userInput}
                        </p>
                        {expandedId === entry.id ? (
                          <ChevronUp className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {formatDate(entry.timestamp)}
                        </span>
                        {entry.category && (
                          <Badge variant="secondary" className="text-xs">
                            {categoryLabels[entry.category]}
                          </Badge>
                        )}
                      </div>
                    </button>

                    <AnimatePresence>
                      {expandedId === entry.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 border-t border-border pt-4 space-y-4">
                            <div>
                              <h4 className="text-xs font-semibold text-muted-foreground mb-1">Calm Breakdown</h4>
                              <p className="text-sm">{entry.response.calmBreakdown}</p>
                            </div>
                            
                            <div>
                              <h4 className="text-xs font-semibold text-muted-foreground mb-1">Reality Check</h4>
                              <ul className="space-y-1">
                                {entry.response.realityCheck.map((point, i) => (
                                  <li key={i} className="text-sm flex gap-2">
                                    <span className="text-[#FF5CA2]">•</span>
                                    <span>{point}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="text-xs font-semibold text-muted-foreground mb-1">Logical Explanations</h4>
                              <ol className="space-y-1">
                                {entry.response.logicalExplanations.map((exp, i) => (
                                  <li key={i} className="text-sm flex gap-2">
                                    <span className="font-semibold text-[#8A00D4]">{i + 1}.</span>
                                    <span>{exp}</span>
                                  </li>
                                ))}
                              </ol>
                            </div>
                            
                            <div>
                              <h4 className="text-xs font-semibold text-muted-foreground mb-1">Action Step</h4>
                              <p className="text-sm">{entry.response.actionStep}</p>
                            </div>
                            
                            <div>
                              <h4 className="text-xs font-semibold text-muted-foreground mb-1">Confidence Booster</h4>
                              <p className="text-sm italic">{entry.response.confidenceBooster}</p>
                            </div>

                            <div className="flex gap-2 pt-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(entry)}
                                data-testid={`button-copy-${entry.id}`}
                              >
                                {copiedId === entry.id ? (
                                  <Check className="w-4 h-4 mr-2 text-green-500" />
                                ) : (
                                  <Copy className="w-4 h-4 mr-2" />
                                )}
                                {copiedId === entry.id ? "Copied!" : "Copy"}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(entry.id)}
                                className="text-destructive hover:text-destructive"
                                data-testid={`button-delete-${entry.id}`}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
