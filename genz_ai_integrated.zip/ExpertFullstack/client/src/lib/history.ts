import type { HistoryEntry } from "@shared/schema";

const HISTORY_KEY = "genz_unover_history";
const MAX_ENTRIES = 10;

export function getHistory(): HistoryEntry[] {
  try {
    const stored = localStorage.getItem(HISTORY_KEY);
    if (!stored) return [];
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

export function addToHistory(entry: HistoryEntry): void {
  try {
    const history = getHistory();
    history.unshift(entry);
    const trimmed = history.slice(0, MAX_ENTRIES);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmed));
  } catch {
    console.error("Failed to save history");
  }
}

export function clearHistory(): void {
  localStorage.removeItem(HISTORY_KEY);
}

export function removeFromHistory(id: string): void {
  try {
    const history = getHistory();
    const filtered = history.filter(entry => entry.id !== id);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered));
  } catch {
    console.error("Failed to remove from history");
  }
}
