import type { ChatScenario, ChatSimulatorCategory } from "@shared/schema";

export const chatScenarios: ChatScenario[] = [
  {
    id: "crush-dm-1",
    category: "crush_dm",
    title: "First DM to Your Crush",
    context: "You've been crushing on someone from class. They just posted a story about a concert.",
    messages: [
      { sender: "other", text: "Posted a story: Just got tickets to see The Weeknd next month!" }
    ],
    choices: [
      { id: "a", text: "Omg no way! I'm literally obsessed with The Weeknd. Which show are you going to?", score: 3, feedback: "Perfect! Shows genuine interest and opens up conversation naturally." },
      { id: "b", text: "hey", score: 1, feedback: "Too vague - give them something to respond to!" },
      { id: "c", text: "I love The Weeknd too! Have you heard his new album?", score: 2, feedback: "Good connection but could be more specific to their post." },
      { id: "d", text: "We should go together sometime", score: 0, feedback: "Too forward for a first message - build rapport first!" }
    ]
  },
  {
    id: "crush-dm-2",
    category: "crush_dm",
    title: "Continuing the Conversation",
    context: "They replied positively to your first message. Keep the momentum going!",
    messages: [
      { sender: "other", text: "Posted a story: Just got tickets to see The Weeknd next month!" },
      { sender: "user", text: "Omg no way! I'm literally obsessed with The Weeknd. Which show are you going to?" },
      { sender: "other", text: "The one in LA! I'm so excited, been waiting forever for this" }
    ],
    choices: [
      { id: "a", text: "That's awesome! LA shows always go hard. What's your favorite song of his?", score: 3, feedback: "Great follow-up! Keeps conversation flowing naturally." },
      { id: "b", text: "Cool", score: 0, feedback: "Conversation killer - always add something to build on!" },
      { id: "c", text: "I wish I could go! Maybe next time", score: 2, feedback: "Shows interest but misses chance to connect more." },
      { id: "d", text: "You should take me lol", score: 1, feedback: "Comes across as pushy - let things develop naturally." }
    ]
  },
  {
    id: "fight-friend-1",
    category: "fight_with_friend",
    title: "They Left You on Read",
    context: "Your best friend has been ignoring your messages for 3 days after you accidentally spoiled their favorite show.",
    messages: [
      { sender: "user", text: "[3 days ago] OMG that ending though! Can't believe they killed him off" },
      { sender: "other", text: "[seen]" }
    ],
    choices: [
      { id: "a", text: "Hey, I'm really sorry about the spoiler. I wasn't thinking. Can we talk?", score: 3, feedback: "Accountability + giving them space to respond. Perfect approach!" },
      { id: "b", text: "Hello?? Are you seriously ignoring me over a TV show??", score: 0, feedback: "Dismissing their feelings will make things worse." },
      { id: "c", text: "I feel bad about what happened. Let me know when you're ready to chat.", score: 2, feedback: "Good, but could acknowledge the specific mistake." },
      { id: "d", text: "*sends meme*", score: 1, feedback: "Deflecting with humor might work later, but address it first." }
    ]
  },
  {
    id: "fight-friend-2",
    category: "fight_with_friend",
    title: "They Finally Reply",
    context: "Your friend responds after your apology. They seem hurt.",
    messages: [
      { sender: "user", text: "Hey, I'm really sorry about the spoiler. I wasn't thinking. Can we talk?" },
      { sender: "other", text: "I mean yeah it really sucked. I was so excited to watch it and now it's ruined" }
    ],
    choices: [
      { id: "a", text: "I totally get it. I'd be upset too. Is there anything I can do to make it up to you?", score: 3, feedback: "Validating their feelings and offering to make amends - great emotional intelligence!" },
      { id: "b", text: "It's just a show though, you'll get over it", score: 0, feedback: "Never minimize someone's feelings, even over 'small' things." },
      { id: "c", text: "I promise I'll never spoil anything again", score: 2, feedback: "Good commitment but doesn't address their current feelings." },
      { id: "d", text: "I said sorry already, what more do you want?", score: 0, feedback: "Defensive responses shut down reconciliation." }
    ]
  },
  {
    id: "ignored-1",
    category: "ignored_messages",
    title: "Group Chat Gone Silent",
    context: "You suggested plans in the group chat 2 days ago. Everyone's been active but no one acknowledged your message.",
    messages: [
      { sender: "user", text: "[2 days ago] Hey! Anyone down to hang out this weekend? Maybe movies or something?" },
      { sender: "other", text: "[Others chatting about random stuff, ignoring your message]" }
    ],
    choices: [
      { id: "a", text: "So about this weekend - I was thinking Saturday afternoon? Who's free?", score: 3, feedback: "Casual bump with specific details makes it easier for people to commit." },
      { id: "b", text: "Guess no one wants to hang with me then...", score: 0, feedback: "Passive-aggressive guilt-tripping pushes people away." },
      { id: "c", text: "Hello?? Did anyone see my message??", score: 1, feedback: "Calling out the ignore can come across as needy." },
      { id: "d", text: "DM one person directly to gauge interest first", score: 2, feedback: "Smart strategy! Sometimes group chats are overwhelming." }
    ]
  },
  {
    id: "confused-1",
    category: "confused_signals",
    title: "Hot and Cold Energy",
    context: "Someone you've been talking to is super engaged in person but barely texts back. They just sent a reply after 6 hours.",
    messages: [
      { sender: "user", text: "[6 hours ago] That was so fun today! We should do it again" },
      { sender: "other", text: "yeah fr! lmk" }
    ],
    choices: [
      { id: "a", text: "For sure! Are you free Thursday or Friday?", score: 3, feedback: "Taking initiative shows confidence and gives them a clear option to commit." },
      { id: "b", text: "You always take forever to reply...", score: 0, feedback: "Never complain about response times - it's a turn-off." },
      { id: "c", text: "Yeah definitely!", score: 2, feedback: "Friendly but leaves the ball in their court - be more proactive." },
      { id: "d", text: "Wait the same amount of time to reply", score: 1, feedback: "Games waste everyone's time. Be authentic!" }
    ]
  },
  {
    id: "college-1",
    category: "college_teacher",
    title: "Asking for an Extension",
    context: "You're overwhelmed with midterms and need to ask your professor for a deadline extension on an assignment due tomorrow.",
    messages: [
      { sender: "other", text: "[Professor's email]: Reminder that the research paper is due tomorrow at 11:59 PM." }
    ],
    choices: [
      { id: "a", text: "Hi Professor, I'm struggling to balance multiple midterms this week. Would it be possible to have a 2-day extension? I want to submit quality work.", score: 3, feedback: "Professional, honest, and shows you care about the work quality." },
      { id: "b", text: "Hey can I get an extension? Things are crazy rn", score: 1, feedback: "Too casual for a professor - match their communication style." },
      { id: "c", text: "I can't do the assignment, there's too much going on", score: 0, feedback: "Sounds like an excuse rather than a genuine request." },
      { id: "d", text: "Don't send anything and just submit late with an apology", score: 0, feedback: "Always communicate beforehand - professors appreciate the heads up." }
    ]
  },
  {
    id: "stranger-1",
    category: "stranger_intro",
    title: "Starting a Convo at a Party",
    context: "You're at a party and notice someone standing alone looking at the decorations. They seem approachable.",
    messages: [],
    choices: [
      { id: "a", text: "Hey! These decorations are pretty cool right? I'm [your name] by the way", score: 3, feedback: "Commenting on something shared + introducing yourself is the classic opener for a reason!" },
      { id: "b", text: "You look lonely, want some company?", score: 0, feedback: "Never call someone 'lonely' - it's patronizing." },
      { id: "c", text: "Hi! Do you know whose party this is?", score: 2, feedback: "Works as an opener, gives them something to answer." },
      { id: "d", text: "Just stand near them and hope they talk first", score: 1, feedback: "Sometimes you gotta make the first move! You got this." }
    ]
  },
  {
    id: "stranger-2",
    category: "stranger_intro",
    title: "Keeping the Conversation Going",
    context: "They responded positively! Now keep it flowing.",
    messages: [
      { sender: "user", text: "Hey! These decorations are pretty cool right? I'm Alex by the way" },
      { sender: "other", text: "Right?? I'm Sam. My friend dragged me here but it's actually not bad" }
    ],
    choices: [
      { id: "a", text: "Same here! So what do you usually do for fun when you're not being dragged to parties?", score: 3, feedback: "Playful callback + asking about them = conversation gold!" },
      { id: "b", text: "Cool cool cool", score: 0, feedback: "Dead end - always add something to build on." },
      { id: "c", text: "Where do you go to school/work?", score: 2, feedback: "Standard but can feel like an interview. Try something more fun!" },
      { id: "d", text: "Yeah parties aren't really my thing either honestly", score: 2, feedback: "Bonding over shared experience works, but keep energy positive." }
    ]
  },
  {
    id: "crush-dm-3",
    category: "crush_dm",
    title: "They're Being Flirty",
    context: "The conversation has been going well and they just sent something that could be flirty...",
    messages: [
      { sender: "other", text: "Haha you're actually really funny. Why haven't we talked before?" }
    ],
    choices: [
      { id: "a", text: "Honestly no idea, but I'm glad we are now! We should hang out sometime", score: 3, feedback: "Confident, reciprocates interest, and suggests next step. Chef's kiss!" },
      { id: "b", text: "Idk lol", score: 0, feedback: "Don't shut down potential! Show some personality." },
      { id: "c", text: "Aw thanks! You seem pretty cool too", score: 2, feedback: "Sweet but doesn't move things forward." },
      { id: "d", text: "Probably because you intimidate me haha", score: 2, feedback: "Vulnerable and cute, but be careful not to seem insecure." }
    ]
  },
  {
    id: "ignored-2",
    category: "ignored_messages",
    title: "They Watched But Didn't Reply",
    context: "You sent a heartfelt message and they viewed your story 5 minutes later but still haven't replied.",
    messages: [
      { sender: "user", text: "[24 hours ago] Hey, I've been thinking about what you said and I think we should talk about it properly" },
      { sender: "other", text: "[Viewed your story 5 min ago]" }
    ],
    choices: [
      { id: "a", text: "Give them more time - they might be processing or busy", score: 3, feedback: "Patience is key. Not everyone processes emotions at the same speed." },
      { id: "b", text: "I saw you viewed my story but can't reply??", score: 0, feedback: "This comes across as accusatory and desperate." },
      { id: "c", text: "Just letting you know I'm here when you're ready", score: 2, feedback: "Supportive, but might add pressure if sent too soon." },
      { id: "d", text: "Send a meme to lighten the mood", score: 1, feedback: "Might work, but could seem like you're not taking things seriously." }
    ]
  },
  {
    id: "confused-2",
    category: "confused_signals",
    title: "Mixed Signals After a Date",
    context: "You had what felt like an amazing date yesterday. They texted 'I had fun!' but haven't mentioned meeting again.",
    messages: [
      { sender: "other", text: "I had fun yesterday!" },
      { sender: "user", text: "Me too! It was really great" },
      { sender: "other", text: "[liked your message]" }
    ],
    choices: [
      { id: "a", text: "There's this cool [place/event] happening this week - would you want to check it out together?", score: 3, feedback: "Direct but casual. Shows initiative without being pushy!" },
      { id: "b", text: "So... do you want to do this again or what?", score: 1, feedback: "Too confrontational - makes them feel put on the spot." },
      { id: "c", text: "Wait for them to suggest something", score: 1, feedback: "Could work, but might miss your chance if they're also waiting!" },
      { id: "d", text: "Analyze the 'liked message' for 3 hours wondering what it means", score: 0, feedback: "We've all been there, but overthinking won't help. Take action!" }
    ]
  }
];

export function getScenariosByCategory(category: ChatSimulatorCategory): ChatScenario[] {
  return chatScenarios.filter(s => s.category === category);
}

export function getRandomScenario(category?: ChatSimulatorCategory): ChatScenario {
  const filtered = category ? getScenariosByCategory(category) : chatScenarios;
  return filtered[Math.floor(Math.random() * filtered.length)];
}

export const categoryLabels: Record<ChatSimulatorCategory, { label: string; icon: string }> = {
  crush_dm: { label: "Crush DM", icon: "Heart" },
  fight_with_friend: { label: "Fight with Friend", icon: "Users" },
  ignored_messages: { label: "Ignored Messages", icon: "MessageCircleOff" },
  confused_signals: { label: "Confused Signals", icon: "HelpCircle" },
  college_teacher: { label: "College/Teacher", icon: "GraduationCap" },
  stranger_intro: { label: "Stranger Intro", icon: "UserPlus" }
};
