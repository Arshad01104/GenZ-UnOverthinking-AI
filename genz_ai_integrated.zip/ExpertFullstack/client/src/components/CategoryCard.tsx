import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";

interface CategoryCardProps {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  className?: string;
  delay?: number;
}

export function CategoryCard({ icon: Icon, label, onClick, className, delay = 0 }: CategoryCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: "easeOut" }}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={cn(
        "group relative p-4 rounded-xl bg-card/50 border border-border/50 backdrop-blur-sm",
        "flex flex-col items-center justify-center gap-3 min-h-[100px]",
        "transition-all duration-300",
        "hover:border-[#8A00D4]/50 hover:bg-card/70",
        "hover:shadow-[0_0_20px_rgba(138,0,212,0.2)]",
        "focus:outline-none focus:ring-2 focus:ring-[#8A00D4]/50 focus:ring-offset-2 focus:ring-offset-background",
        className
      )}
      data-testid={`category-${label.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="p-3 rounded-full bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20 group-hover:from-[#8A00D4]/30 group-hover:to-[#FF5CA2]/30 transition-all">
        <Icon className="w-6 h-6 text-[#FF5CA2] group-hover:text-[#FF6DB3] transition-colors" />
      </div>
      <span className="text-sm font-medium text-foreground/90 text-center group-hover:text-foreground transition-colors">
        {label}
      </span>
    </motion.button>
  );
}
