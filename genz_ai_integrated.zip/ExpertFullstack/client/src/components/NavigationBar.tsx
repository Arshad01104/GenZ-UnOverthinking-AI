import { useLocation, Link } from "wouter";
import { Home, MessageSquare, Timer, History, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/chat", icon: MessageSquare, label: "Chat" },
  { path: "/simulator", icon: Sparkles, label: "Practice" },
  { path: "/reset", icon: Timer, label: "Reset" },
  { path: "/history", icon: History, label: "History" }
];

export function NavigationBar() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card/95 backdrop-blur-lg border-t border-border safe-area-bottom">
      <div className="flex items-center justify-around px-2 py-2 max-w-lg mx-auto">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location === path || (path !== "/" && location.startsWith(path));
          
          return (
            <Link key={path} href={path}>
              <motion.div
                className={cn(
                  "relative flex flex-col items-center justify-center px-3 py-2 rounded-xl transition-all cursor-pointer",
                  isActive 
                    ? "text-white" 
                    : "text-muted-foreground hover:text-foreground"
                )}
                whileTap={{ scale: 0.9 }}
                data-testid={`nav-${label.toLowerCase()}`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2]"
                    transition={{ type: "spring", duration: 0.5 }}
                  />
                )}
                <Icon className={cn("w-5 h-5 relative z-10", isActive && "text-white")} />
                <span className={cn("text-xs mt-1 relative z-10 font-medium", isActive && "text-white")}>
                  {label}
                </span>
              </motion.div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
