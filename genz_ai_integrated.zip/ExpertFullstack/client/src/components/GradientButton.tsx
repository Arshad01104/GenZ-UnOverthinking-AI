import { cn } from "@/lib/utils";
import { forwardRef } from "react";

interface GradientButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
  size?: "sm" | "md" | "lg";
  isLoading?: boolean;
}

const GradientButton = forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ className, variant = "primary", size = "md", isLoading, children, disabled, ...props }, ref) => {
    const baseStyles = "relative font-medium rounded-lg transition-all duration-300 transform focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background disabled:opacity-50 disabled:cursor-not-allowed";
    
    const variants = {
      primary: "bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] text-white hover:shadow-[0_0_30px_rgba(138,0,212,0.5)] hover:scale-[1.02] active:scale-[0.98] focus:ring-[#8A00D4]",
      secondary: "bg-secondary/50 text-foreground border border-[#8A00D4]/30 hover:border-[#8A00D4]/60 hover:bg-secondary/70 focus:ring-[#8A00D4]",
      outline: "bg-transparent border-2 border-transparent bg-clip-padding hover:scale-[1.02] active:scale-[0.98] focus:ring-[#8A00D4]"
    };

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg"
    };

    return (
      <button
        ref={ref}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        disabled={disabled || isLoading}
        {...props}
      >
        {variant === "outline" && (
          <span className="absolute inset-0 rounded-lg bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] -z-10" style={{ padding: "2px" }}>
            <span className="absolute inset-[2px] rounded-[6px] bg-background" />
          </span>
        )}
        {isLoading ? (
          <span className="flex items-center justify-center gap-2">
            <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            <span>Loading...</span>
          </span>
        ) : (
          <span className={variant === "outline" ? "relative bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] bg-clip-text text-transparent font-semibold" : ""}>
            {children}
          </span>
        )}
      </button>
    );
  }
);

GradientButton.displayName = "GradientButton";

export { GradientButton };
