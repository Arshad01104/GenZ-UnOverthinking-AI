export function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 p-4 rounded-2xl bg-gradient-to-r from-[#8A00D4]/20 to-[#FF5CA2]/20 max-w-[80px]">
      <span className="w-2 h-2 rounded-full bg-[#8A00D4] animate-bounce-dots" style={{ animationDelay: "0s" }} />
      <span className="w-2 h-2 rounded-full bg-[#9B10E5] animate-bounce-dots" style={{ animationDelay: "0.2s" }} />
      <span className="w-2 h-2 rounded-full bg-[#FF5CA2] animate-bounce-dots" style={{ animationDelay: "0.4s" }} />
    </div>
  );
}
