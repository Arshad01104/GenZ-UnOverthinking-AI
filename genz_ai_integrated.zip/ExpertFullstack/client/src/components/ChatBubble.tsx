import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ChatBubbleProps {
  sender: "user" | "ai";
  children: React.ReactNode;
  className?: string;
}

export function ChatBubble({ sender, children, className }: ChatBubbleProps) {
  const isUser = sender === "user";
  
  return (
    <motion.div
      initial={{ opacity: 0, x: isUser ? 20 : -20, y: 10 }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn(
        "max-w-[85%] md:max-w-[75%] rounded-2xl p-4 relative",
        isUser 
          ? "ml-auto bg-[#5D3FD3]/60 text-white rounded-br-md" 
          : "mr-auto bg-gradient-to-r from-[#8A00D4] to-[#FF5CA2] text-white rounded-bl-md shadow-lg shadow-[#8A00D4]/20",
        className
      )}
    >
      {children}
    </motion.div>
  );
}
