import { motion, AnimatePresence } from "framer-motion";
import { Heart, Phone, ExternalLink, X } from "lucide-react";
import { GradientButton } from "./GradientButton";

interface SafetyOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SafetyOverlay({ isOpen, onClose }: SafetyOverlayProps) {
  const resources = [
    { name: "National Suicide Prevention Lifeline", number: "988", url: "https://988lifeline.org" },
    { name: "Crisis Text Line", number: "Text HOME to 741741", url: "https://www.crisistextline.org" },
    { name: "International Association for Suicide Prevention", number: "Find local resources", url: "https://www.iasp.info/resources/Crisis_Centres/" }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/90 backdrop-blur-md"
          data-testid="safety-overlay"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative max-w-md w-full bg-card border-2 border-destructive/30 rounded-2xl p-6 shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-muted transition-colors"
              data-testid="button-close-safety"
              aria-label="Close"
            >
              <X className="w-5 h-5 text-muted-foreground" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-full bg-destructive/20">
                <Heart className="w-6 h-6 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold text-foreground">We Care About You</h2>
            </div>

            <p className="text-muted-foreground mb-6 leading-relaxed">
              It sounds like you might be going through something really difficult right now. 
              Whatever you're feeling, you're not alone. Please consider reaching out to 
              someone who can help.
            </p>

            <div className="space-y-3 mb-6">
              {resources.map((resource) => (
                <a
                  key={resource.name}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors group"
                  data-testid={`link-resource-${resource.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Phone className="w-5 h-5 text-[#8A00D4]" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground text-sm">{resource.name}</p>
                    <p className="text-xs text-muted-foreground">{resource.number}</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                </a>
              ))}
            </div>

            <p className="text-sm text-muted-foreground mb-4">
              This app is here to help with everyday stress and overthinking, but it's not a 
              substitute for professional mental health support. You deserve real help.
            </p>

            <GradientButton 
              onClick={onClose} 
              variant="secondary" 
              className="w-full"
              data-testid="button-continue-safety"
            >
              I understand, continue to app
            </GradientButton>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
